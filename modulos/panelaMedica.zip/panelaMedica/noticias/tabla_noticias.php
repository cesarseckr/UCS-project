 <div class="form-row">
    <div class="form-group col-7"></div>
    <div class="form-group col-5">
      <label>Categorías:</label>
      <SELECT type="text" class="form-control" id="select-categorias">
      </SELECT>
    </div>
  </div>
  
  <div id="tabla" class="table-responsive" style="padding-bottom: 15px;">
  <table id="tabla-1" class="table table-bordered" cellspacing="0" width="100%">
    <tbody id="tbody_articulos">
    </tbody>
  </table>
</div> 