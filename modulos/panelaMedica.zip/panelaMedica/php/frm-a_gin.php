
  <div class="form-row">
  	<div class="form-group col-12" style="display: none">
	  <label>ID A.Gin</label>
	  <input type="text" class="form-control" name="id_gin" id="id_gin" placeholder="Id A.NoPat">
	</div>
	<div class="form-group col-2">
	  <label>Embarazos</label>
	  <input type="text" class="form-control" name="embarazos" id="embarazos" placeholder="Embarazos">
	</div>
	<div class="form-group col-2">
	  <label>Partos</label>
	  <input type="text" class="form-control" name="partos" id="partos" placeholder="Partos">
	</div>
	<div class="form-group col-2">
	  <label>Cesareas</label>
	  <input type="text" class="form-control" name="cesarias" id="cesarias" placeholder="Cesareas">
	</div>
	<div class="form-group col-2">
	  <label>Abortos</label>
	  <input type="text" class="form-control" name="abortos" id="abortos" placeholder="Abortos">
	</div>
	<div class="form-group col-2">
	  <label>FUM</label>
	  <input type="text" class="form-control" name="fum" id="fum" placeholder="FUM">
	</div>
  </div>

  <div class="form-row">
	<div class="form-group col-3">
	  <label>Salpingoclasia</label>
	  <input type="text" class="form-control" name="salpi" id="salpi" placeholder="Salpingoclasia">
	</div>
	<div class="form-group col-3">
	  <label>Histerectomia</label>
	  <input type="text" class="form-control" name="hister" id="hister" placeholder="Histerectomia">
	</div>
	<div class="form-group col-3">
	  <label>Quistes</label>
	  <input type="text" class="form-control" name="quistes" id="quistes" placeholder="Quistes">
	</div>
	<div class="form-group col-3">
	  <label>Hemorragias</label>
	  <input type="text" class="form-control" name="hemorr" id="hemorr" placeholder="Hemorragias">
	</div>
  </div>
  <div class="form-row">
	<div class="form-group col-12">
	  <label>Observaciones</label>
	  <TEXTAREA class="form-control" name="obs_gin" id="obs_gin" placeholder="Observaciones"></TEXTAREA>
	</div>
  </div>
