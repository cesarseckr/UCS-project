<div class="modal fade" id="sumar-medicamento" tabindex="-1" role="dialog" aria-labelledby="mod-material" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-plus"></i>&nbsp;Aumentar cantidad Medicamento</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group" style="display: none" >
          <label>idmedicamento</label>
          <input type="text" class="form-control" name="idmed-sum" id="idmed-sum">
        </div>
        <div class="form-group">
          <label>Cantidad</label>
          <input type="text" class="form-control" name="cantidadmed-sum" id="cantidadmed-sum">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary btn-sm" id="sumar_med">Modificar material</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
