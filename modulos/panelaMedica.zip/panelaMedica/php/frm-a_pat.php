
  <div class="form-row">
  	<div class="form-group col-12" style="display: none">
	  <label>ID A.Pat</label>
	  <input type="text" class="form-control" name="id_pat" id="id_pat" placeholder="Id A.NoPat">
	</div>
  	<div class="form-group col-3">
	  <label>Hipertensión</label>
	  <input type="text" class="form-control" name="hipertension" id="hipertension" placeholder="Hipertensión">
	</div>
	<div class="form-group col-3">
	  <label>Cardiacas</label>
	  <input type="text" class="form-control" name="cardiacas" id="cardiacas" placeholder="Cardiacas">
	</div>
	<div class="form-group col-3">
	  <label>Respiratorias</label>
	  <input type="text" class="form-control" name="respiratorias" id="respiratorias" placeholder="Respiratorias">
	</div>
	<div class="form-group col-3">
	  <label>Tiroides</label>
	  <input type="text" class="form-control" name="tiroides" id="tiroides" placeholder="Tiroides">
	</div>
  </div>

  <div class="form-row">
	<div class="form-group col-4">
	  <label>Diabetes</label>
	  <input type="text" class="form-control" name="diabetes" id="diabetes" placeholder="Diabetes">
	</div>
	<div class="form-group col-4">
	  <label>Digestivas</label>
	  <input type="text" class="form-control" name="digestivas" id="digestivas" placeholder="Digestivas">
	</div>
	
	<div class="form-group col-4">
	  <label>Piel</label>
	  <input type="text" class="form-control" name="piel_pat" id="piel_pat" placeholder="Piel">
	</div>
  </div>

  <div class="form-row">
  	<div class="form-group col-3">
	  <label>Onicomicosis</label>
	  <input type="text" class="form-control" name="oni" id="oni" placeholder="Onicomicosis">
	</div>
	<div class="form-group col-3">
	  <label>Convulsiones</label>
	  <input type="text" class="form-control" name="convulsiones" id="convulsiones" placeholder="Convulsiones">
	</div>
	<div class="form-group col-3">
	  <label>Transfusiones</label>
	  <input type="text" class="form-control" name="transf" id="transf" placeholder="Transfusiones">
	</div>
	<div class="form-group col-3">
	  <label>Renales</label>
	  <input type="text" class="form-control" name="renal" id="renal" placeholder="Renales">
	</div>
  </div>