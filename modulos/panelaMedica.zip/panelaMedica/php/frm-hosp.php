
  <div class="form-row">
	<div class="form-group col-5">
	  <label>¿Tiene Hospitalizaciones?</label>
	  <select class="form-control" name="hos" id="hos">
	  	<option value="0">Seleccionar</option>
	  	<option value="1">Si</option>
	  	<option value="2">No</option>
	  </select>
	</div>
	<div class="form-group col-5">
	  <label>Fecha y Motivo</label>
	  <TEXTAREA class="form-control" name="f_motiv" id="f_motiv" placeholder="Fecha y Motivo"></TEXTAREA>
	</div>
  </div>
