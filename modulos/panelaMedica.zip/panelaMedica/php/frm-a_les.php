
<div class="form-row">
	<div class="form-group col-12" style="display: none">
	  <label>ID A.Less</label>
	  <input type="text" class="form-control" name="id_les" id="id_les" placeholder="Id A.NoPat">
	</div>
	<div class="form-group col-4">
	  <label>Esguince Cervical</label>
	  <input type="text" class="form-control" name="esg_c" id="esg_c" placeholder="Esguince cervical">
	</div>
	<div class="form-group col-4">
	  <label>Esguince de Tobillo</label>
	  <input type="text" class="form-control" name="esg_t" id="esg_t" placeholder="Esguince de Tobillo">
	</div>
	<div class="form-group col-4">
	  <label>Esguince de Rodidilla</label>
	  <input type="text" class="form-control" name="esg_r" id="esg_r" placeholder="Esguince de Rodidilla">
	</div>
</div>

  <div class="form-row">
  	<div class="form-group col-4">
	  <label>Luxacion de Hombro</label>
	  <input type="text" class="form-control" name="lux_h" id="lux_h" placeholder="Luxacion de Hombro">
	</div>
	<div class="form-group col-4">
	  <label>Luxacion de Rodilla</label>
	  <input type="text" class="form-control" name="lux_r" id="lux_r" placeholder="Luxacion de Rodilla">
	</div>
	<div class="form-group col-4">
	  <label>Lumbalgias</label>
	  <input type="text" class="form-control" name="lumb" id="lumb" placeholder="Lumbalgias">
	</div>
  </div>

   <div class="form-row">
    <div class="form-group col-6">
	  <label>Fracturas</label>
	  <input type="text" class="form-control" name="fract" id="fract" placeholder="Fracturas">
	</div>
	<div class="form-group col-6">
	  <label>Hernia Abdominal/Ubilical/Inguinal</label>
	  <input type="text" class="form-control" name="hernia" id="hernia" placeholder="Hernia Abdominal/Ubilical/Inguinal">
	</div>
  </div>

  <div class="form-row">
	<div class="form-group col-12">
	  <label>Otras</label>
	  <TEXTAREA class="form-control" name="otras_ales" id="otras_ales" placeholder="Otras"></TEXTAREA>
	</div>
  </div>