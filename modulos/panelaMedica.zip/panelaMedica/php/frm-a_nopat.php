
  <div class="form-row">
  	<div class="form-group col-12" style="display: none">
	  <label>ID A.NoPat</label>
	  <input type="text" class="form-control" name="id_nopat" id="id_nopat" placeholder="Id A.NoPat">
	</div>
	<div class="form-group col-3">
	  <label>Alcoholismo</label>
	  <input type="text" class="form-control" name="alcoholismo" id="alcoholismo" placeholder="Nombre del paciente">
	</div>
	<div class="form-group col-3">
	  <label>Tabaquismo</label>
	  <input type="text" class="form-control" name="tabaquismo" id="tabaquismo" placeholder="Tabaquismo">
	</div>
	<div class="form-group col-3">
	  <label>Alergias</label>
	  <input type="text" class="form-control" name="alergias" id="alergias" placeholder="Alergias">
	</div>
	<div class="form-group col-3">
	  <label>Toxicomanias</label>
	  <input type="text" class="form-control" name="toxi" id="toxi" placeholder="Toxicomanias">
	</div>
  </div>

  <div class="form-row">
	<div class="form-group col-2">
	  <label>¿Toma medicamentos?</label>
	  <select class="form-control" name="res_med" id="res_med">
	  	<option value="0">Seleccionar</option>
	  	<option value="1">Si</option>
	  	<option value="2">No</option>
	  </select>
	</div>
	<div class="form-group col-10">
	  <label>Especifique</label>
	  <TEXTAREA class="form-control" name="especificacion" id="especificacion" placeholder="Especifique"></TEXTAREA>
	</div>
  </div>

  <div class="form-row">
	<div class="form-group col-4">
	  <label>Cicatrices</label>
	  <input type="text" class="form-control" name="cicatrices" id="cicatrices" placeholder="Cicatrices">
	</div>
	<div class="form-group col-4">
	  <label>Tatuajes</label>
	  <input type="text" class="form-control" name="tatuajes" id="tatuajes" placeholder="Tatuajes">
	</div>
	<div class="form-group col-4">
	  <label>Amputaciones</label>
	  <input type="text" class="form-control" name="amputaciones" id="amputaciones" placeholder="Amputaciones">
	</div>
  </div>